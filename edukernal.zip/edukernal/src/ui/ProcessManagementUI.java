package ui;

import core.MemoryManager;
import core.Scheduler;
import model.Process;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import core.Printer;

public class ProcessManagementUI extends JPanel {
    private final List<Process> processList = new ArrayList<>();
    private final Scheduler scheduler = new Scheduler();
    private final DefaultTableModel tableModel;
    private JLabel cpuLabel;
    private JTextArea ioTextArea;
    private final Printer printer = new Printer();

    public ProcessManagementUI() {
        setLayout(new BorderLayout());

        // ==== Top Button Panel ====
        JPanel topPanel = new JPanel(new GridLayout(2, 5, 10, 5));  // 2 rows x 5 columns

        JButton createBtn = new JButton("Create Process");
        createBtn.addActionListener(e -> createProcess());

        JButton runFCFSBtn = new JButton("Run FCFS");
        runFCFSBtn.addActionListener(e -> {
            String msg = scheduler.runFCFS();
            JOptionPane.showMessageDialog(this, msg);
            refreshTable();
        });
        JButton communicateBtn = new JButton("Send Message");
        communicateBtn.addActionListener(e -> {
            try {
                int senderId = Integer.parseInt(JOptionPane.showInputDialog("Enter Sender PID:"));
                int receiverId = Integer.parseInt(JOptionPane.showInputDialog("Enter Receiver PID:"));
                String message = JOptionPane.showInputDialog("Enter Message:");

                Process sender = findProcessById(senderId);
                Process receiver = findProcessById(receiverId);

                if (sender != null && receiver != null) {
                    receiver.setMessage(message);
                    JOptionPane.showMessageDialog(this, "Message sent!");
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid PIDs.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error during message sending.");
            }
        });



        JButton runPriorityBtn = new JButton("Run Priority");
        runPriorityBtn.addActionListener(e -> {
            String msg = scheduler.runPriority();
            JOptionPane.showMessageDialog(this, msg);
            refreshTable();
        });

        JButton terminateBtn = new JButton("Terminate");
        terminateBtn.addActionListener(e -> {
            Process running = scheduler.getRunningProcess();
            if (running != null) {
                MemoryManager.getInstance().deallocateMemory(running.getPid());
                scheduler.terminateCurrent();
                scheduler.dispatchNext();
                JOptionPane.showMessageDialog(this, "Process PID " + running.getPid() + " terminated.");
                refreshTable();
            } else {
                JOptionPane.showMessageDialog(this, "No process is currently running.");
            }
        });

        JButton blockBtn = new JButton("Block");
        blockBtn.addActionListener(e -> {
            if (scheduler.getRunningProcess() != null) {
                scheduler.blockCurrent();
                JOptionPane.showMessageDialog(this, "Running process blocked.");
                refreshTable();
            } else {
                JOptionPane.showMessageDialog(this, "No process is currently running.");
            }
        });

        JButton resumeBtn = new JButton("Resume");
        resumeBtn.addActionListener(e -> {
            scheduler.resumeBlocked();
            JOptionPane.showMessageDialog(this, "Blocked process resumed.");
            refreshTable();
        });

        JButton destroyBtn = new JButton("Destroy");
        destroyBtn.addActionListener(e -> {
            scheduler.terminateCurrent();
            JOptionPane.showMessageDialog(this, "Running process destroyed.");
            refreshTable();
        });

//        JButton communicateBtn = new JButton("Send Message");
//        communicateBtn.addActionListener(e -> {
//            try {
//                int senderId = Integer.parseInt(JOptionPane.showInputDialog("Enter Sender PID:"));
//                int receiverId = Integer.parseInt(JOptionPane.showInputDialog("Enter Receiver PID:"));
//                String message = JOptionPane.showInputDialog("Enter Message:");
//
//                Process sender = findProcessById(senderId);
//                Process receiver = findProcessById(receiverId);
//
//                if (sender != null && receiver != null) {
//                    receiver.setMessage(message);
//                    JOptionPane.showMessageDialog(this, "Message sent!");
//                } else {
//                    JOptionPane.showMessageDialog(this, "Invalid PIDs.");
//                }
//            } catch (Exception ex) {
//                JOptionPane.showMessageDialog(this, "Error during message sending.");
//            }
//        });

        JButton printBtn = new JButton("Use Shared Printer");
        printBtn.addActionListener(e -> {
            Process running = scheduler.getRunningProcess();
            if (running != null) {
                printer.usePrinter("PID " + running.getPid());
            } else {
                JOptionPane.showMessageDialog(this, "No process is currently running.");
            }
        });

        // ==== Add Buttons to Panel ====
        topPanel.add(createBtn);
        topPanel.add(runFCFSBtn);
        topPanel.add(runPriorityBtn);
        topPanel.add(terminateBtn);
        topPanel.add(blockBtn);
        topPanel.add(resumeBtn);
        topPanel.add(destroyBtn);
        topPanel.add(communicateBtn);
        topPanel.add(printBtn);

        // ==== Process Table ====
        String[] columns = {"PID", "State", "Owner", "Priority", "Memory", "Arrival", "Burst", "Processor", "IO State", "Message"};
        tableModel = new DefaultTableModel(columns, 0);
        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // ==== CPU + I/O Status Panel ====
        JPanel bottomPanel = new JPanel(new GridLayout(1, 2));

        cpuLabel = new JLabel("CPU: [Idle]");
        cpuLabel.setFont(new Font("Arial", Font.BOLD, 14));
        cpuLabel.setBorder(BorderFactory.createTitledBorder("CPU"));
        cpuLabel.setHorizontalAlignment(SwingConstants.CENTER);

        ioTextArea = new JTextArea(5, 20);
        ioTextArea.setEditable(false);
        ioTextArea.setBorder(BorderFactory.createTitledBorder("I/O Devices"));

        bottomPanel.add(cpuLabel);
        bottomPanel.add(new JScrollPane(ioTextArea));

        // ==== Add Panels to Layout ====
        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void createProcess() {
        JTextField ownerField = new JTextField();
        JTextField priorityField = new JTextField();
        JTextField memoryField = new JTextField();
        JTextField arrivalField = new JTextField();
        JTextField burstField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.add(new JLabel("Owner:"));
        panel.add(ownerField);
        panel.add(new JLabel("Priority:"));
        panel.add(priorityField);
        panel.add(new JLabel("Memory (MB):"));
        panel.add(memoryField);
        panel.add(new JLabel("Arrival Time:"));
        panel.add(arrivalField);
        panel.add(new JLabel("Burst Time:"));
        panel.add(burstField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Enter Process Details",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            try {
                String owner = ownerField.getText();
                int priority = Integer.parseInt(priorityField.getText());
                int memory = Integer.parseInt(memoryField.getText());
                int arrival = Integer.parseInt(arrivalField.getText());
                int burst = Integer.parseInt(burstField.getText());

                Process p = new Process(owner, priority, memory, arrival, burst);
                processList.add(p);
                scheduler.addProcess(p);
                MemoryManager.getInstance().allocateMemory(p);
                refreshTable();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please try again.");
            }
        }
    }

    private Process findProcessById(int pid) {
        for (Process p : processList) {
            if (p.getPid() == pid) return p;
        }
        return null;
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (Process p : processList) {
            Object[] row = {
                    p.getPid(),
                    p.getState(),
                    p.getOwner(),
                    p.getPriority(),
                    p.getMemoryRequired(),
                    p.getArrivalTime(),
                    p.getBurstTime(),
                    p.getProcessor(),
                    p.getIoState(),
                    p.getMessage()
            };
            tableModel.addRow(row);
        }

        // Update CPU display
        Process running = scheduler.getRunningProcess();
        cpuLabel.setText(running != null ? "CPU: Running PID " + running.getPid() : "CPU: [Idle]");

        // Update I/O display
        StringBuilder ioInfo = new StringBuilder();
        for (Process p : scheduler.getBlockedQueue()) {
            ioInfo.append("PID ").append(p.getPid())
                    .append(" - ").append(p.getIoState()).append("\n");
        }
        ioTextArea.setText(ioInfo.toString().isEmpty() ? "[No I/O activity]" : ioInfo.toString());
    }
}
