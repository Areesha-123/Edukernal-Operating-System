package ui;

import core.MemoryManager;

import javax.swing.*;
import java.awt.*;

public class ControlPanel extends JFrame {

    private JPanel mainPanel;

    public ControlPanel() {
        setTitle("EduKernel - OS Kernel Simulation");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // Menu buttons
        JButton processBtn = new JButton("Process Management");
        JButton memoryBtn = new JButton("Memory Management");
       // configBtn.addActionListener(e -> openConfigurationDialog());

        JButton configBtn = new JButton("Configuration");

        // Menu panel
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new GridLayout(1, 4, 10, 10));
        menuPanel.add(processBtn);
        menuPanel.add(memoryBtn);
        menuPanel.add(configBtn);

        // Main panel where different content loads
        mainPanel = new JPanel(new BorderLayout());

        // Button Actions


        processBtn.addActionListener(e -> switchTo(new ProcessManagementUI()));
        configBtn.addActionListener(e -> openConfigurationDialog());
      //  memoryBtn.addActionListener(e -> switchTo(new JLabel("COMING SOON")));
        memoryBtn.addActionListener(e -> {
            JFrame frame = new JFrame("Memory Management");
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setSize(500, 400);
            frame.add(new MemoryManagementUI()); // <== must exist
            frame.setVisible(true);
        });



        // Add to frame
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(menuPanel, BorderLayout.NORTH);
        getContentPane().add(mainPanel, BorderLayout.CENTER);
    }

    private void switchTo(JComponent panel) {
        mainPanel.removeAll();
        mainPanel.add(panel, BorderLayout.CENTER);
        mainPanel.revalidate();
        mainPanel.repaint();
    }
    private void openConfigurationDialog() {
        String currentPageSize = readCurrentPageSize();
        JTextField pageSizeField = new JTextField(currentPageSize);

        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.add(new JLabel("Set Page Size (MB):"));
        panel.add(pageSizeField);

        int result = JOptionPane.showConfirmDialog(this, panel, "Kernel Configuration",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            try {
                int newSize = Integer.parseInt(pageSizeField.getText());
                updateMemoryConfigFile(newSize);
                JOptionPane.showMessageDialog(this, "Page size updated. Please restart the app to apply changes.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid page size.");
            }
        }
    }

    private String readCurrentPageSize() {
        try {
            return java.nio.file.Files.readAllLines(java.nio.file.Paths.get("memory_config.txt")).get(0).trim();
        } catch (Exception e) {
            return "4"; // default
        }
    }

    private void updateMemoryConfigFile(int newPageSize) {
        try (java.io.FileWriter writer = new java.io.FileWriter("memory_config.txt")) {
            writer.write(String.valueOf(newPageSize));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
