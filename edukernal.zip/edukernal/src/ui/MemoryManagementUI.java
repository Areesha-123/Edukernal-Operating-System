package ui;

import core.MemoryManager;
import model.Frame;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class MemoryManagementUI extends JPanel {
    private final JTable table;
    private final DefaultTableModel tableModel;

    public MemoryManagementUI() {
        setLayout(new BorderLayout());

        tableModel = new DefaultTableModel(new String[]{"Frame", "PID", "Page #"}, 0);
        table = new JTable(tableModel);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton refreshBtn = new JButton("Refresh");
        refreshBtn.addActionListener(e -> refresh());

        add(refreshBtn, BorderLayout.SOUTH);
    }

    private void refresh() {
        tableModel.setRowCount(0);
        // MemoryManager mm = new MemoryManager();
        MemoryManager mm = MemoryManager.getInstance();//You should pass shared instance
        for (Frame f : mm.getMemoryFrames()) {
            if (f.isOccupied()) {
                tableModel.addRow(new Object[]{
                        f.getFrameNumber(),
                        f.getProcessId(),
                        f.getPageNumber()
                });
            }
        }
    }
}
