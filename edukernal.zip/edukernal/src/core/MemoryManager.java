// MemoryManager.java (Singleton + LRU Paging)
package core;

import model.Frame;
import model.PageTableEntry;
import model.Process;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class MemoryManager {
    private static MemoryManager instance;

    private final int totalFrames = 16;
    private final List<Frame> memoryFrames = new ArrayList<>();
    private final Map<Integer, List<PageTableEntry>> pageTables = new HashMap<>();
    private final LinkedList<Integer> lruQueue = new LinkedList<>();

    private int pageSize = 4;

    private MemoryManager() {
        loadPageSize();
        for (int i = 0; i < totalFrames; i++) {
            memoryFrames.add(new Frame(i));
        }
    }

    public static MemoryManager getInstance() {
        if (instance == null) {
            instance = new MemoryManager();
        }
        return instance;
    }

    private void loadPageSize() {
        try (BufferedReader reader = new BufferedReader(new FileReader("memory_config.txt"))) {
            pageSize = Integer.parseInt(reader.readLine().trim());
            System.out.println("Page size set to: " + pageSize);
        } catch (IOException | NumberFormatException e) {
            System.out.println("Using default page size: " + pageSize);
        }
    }

    public void allocateMemory(Process process) {
        int pagesRequired = (int) Math.ceil((double) process.getMemoryRequired() / pageSize);
        List<PageTableEntry> pageTable = new ArrayList<>();

        for (int i = 0; i < pagesRequired; i++) {
            int frameIndex = findFreeFrame();

            if (frameIndex == -1) {
                frameIndex = applyLRUReplacement(process.getPid(), i);
            }

            Frame frame = memoryFrames.get(frameIndex);
            frame.setOccupied(true);
            frame.setProcessId(process.getPid());
            frame.setPageNumber(i);

            pageTable.add(new PageTableEntry(i, frameIndex));
            updateLRU(frameIndex);
        }

        pageTables.put(process.getPid(), pageTable);
        System.out.println("Memory allocated to PID " + process.getPid() + " with " + pagesRequired + " pages.");
    }

    public void deallocateMemory(int pid) {
        for (Frame frame : memoryFrames) {
            if (frame.getProcessId() == pid) {
                frame.reset();
                lruQueue.remove(Integer.valueOf(frame.getFrameNumber()));
            }
        }
        pageTables.remove(pid);
        System.out.println("Memory deallocated for PID " + pid);
    }

    private int findFreeFrame() {
        for (Frame frame : memoryFrames) {
            if (!frame.isOccupied()) {
                return frame.getFrameNumber();
            }
        }
        return -1;
    }

    private int applyLRUReplacement(int pid, int pageNumber) {
        int frameToReplace = lruQueue.removeFirst();

        Frame frame = memoryFrames.get(frameToReplace);
        int evictedPid = frame.getProcessId();
        System.out.println("Evicting page from PID " + evictedPid + " from frame " + frameToReplace);

        List<PageTableEntry> evictedPageTable = pageTables.get(evictedPid);
        if (evictedPageTable != null) {
            evictedPageTable.removeIf(entry -> entry.getFrameNumber() == frameToReplace);
        }

        frame.setProcessId(pid);
        frame.setPageNumber(pageNumber);

        return frameToReplace;
    }

    private void updateLRU(int frameNumber) {
        lruQueue.remove(Integer.valueOf(frameNumber));
        lruQueue.addLast(frameNumber);
    }

    public List<Frame> getMemoryFrames() {
        return memoryFrames;
    }

    public Map<Integer, List<PageTableEntry>> getPageTables() {
        return pageTables;
    }
}
