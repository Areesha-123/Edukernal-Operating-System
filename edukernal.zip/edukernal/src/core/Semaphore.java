package core;

public class Semaphore {
    private int value;

    public Semaphore(int initial) {
        this.value = initial;
    }

    public synchronized void waitSemaphore(String processName) {
        while (value <= 0) {
            try {
                System.out.println(processName + " is waiting for the resource...");
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        value--;
        System.out.println(processName + " entered critical section.");
    }

    public synchronized void signalSemaphore(String processName) {
        value++;
        System.out.println(processName + " exited critical section.");
        notify();
    }
}
