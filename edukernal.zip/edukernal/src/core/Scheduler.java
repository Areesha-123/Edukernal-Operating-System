package core;

import model.Process;

import java.util.*;

public class Scheduler {
    private Process runningProcess ;

    private Queue<Process> readyQueue = new LinkedList<>();
    private Queue<Process> blockedQueue = new LinkedList<>();
    //private Process runningProcess ;

    // Add new process to the ready queue
    public void addProcess(Process p) {
        p.setState("Ready");
        readyQueue.add(p);
    }

    // FCFS scheduling
    public String runFCFS() {
        if (runningProcess != null) {
            return "Process already running: PID " + runningProcess.getPid();
        }

        if (readyQueue.isEmpty()) {
            return "No process in ready queue.";
        }

        Process next = readyQueue.poll();
        next.setState("Running");
        runningProcess = next;
        return "Running (FCFS) PID: " + next.getPid();
    }

    // Priority scheduling
    public String runPriority() {
        if (runningProcess != null) {
            return "Process already running: PID " + runningProcess.getPid();
        }

        if (readyQueue.isEmpty()) {
            return "No process in ready queue.";
        }

        Process highest = Collections.max(readyQueue, Comparator.comparingInt(Process::getPriority));
        readyQueue.remove(highest);
        highest.setState("Running");
        runningProcess = highest;
        return "Running (priority) PID: " + highest.getPid();
    }
    public void dispatchNext() {
        if (runningProcess != null) return; // only dispatch if no process is running

        if (!readyQueue.isEmpty()) {
            runningProcess = readyQueue.poll(); // get next process from ready queue
            runningProcess.setState("Running");
            System.out.println("Dispatched PID " + runningProcess.getPid() + " to CPU.");
        } else {
            System.out.println("No processes in ready queue to dispatch.");
        }
    }

    // Terminate (destroy) the current running process
    public void terminateCurrent() {
        if (runningProcess != null) {
            runningProcess.setState("Terminated");
            runningProcess = null;

            // Auto-run next process if available
            if (!readyQueue.isEmpty()) {
                Process next = readyQueue.poll();
                next.setState("Running");
                runningProcess = next;
            }
        }
    }


    // Block the current running process
    public void blockCurrent() {
        if (runningProcess != null) {
            runningProcess.setState("Blocked");
            runningProcess.setIoState("Waiting for I/O...");
            blockedQueue.add(runningProcess);
            runningProcess = null;
        }
    }


    // Resume one blocked process and return it to ready queue
    public void resumeBlocked() {
        if (!blockedQueue.isEmpty()) {
            Process p = blockedQueue.poll();
            p.setState("Ready");
            p.setIoState("Idle");
            readyQueue.add(p);
        }
    }


    // Getter for running process
    public Process getRunningProcess() {
        return runningProcess;
    }

    // Getter for queues (optional if needed)
    public Queue<Process> getReadyQueue() {
        return readyQueue;
    }

    public Queue<Process> getBlockedQueue() {
        return blockedQueue;
    }
}
