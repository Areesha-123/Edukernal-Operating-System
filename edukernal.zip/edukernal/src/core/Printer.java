
package core;

public class Printer {
    private final Semaphore semaphore = new Semaphore(1);

    public void usePrinter(String processName) {
        new Thread(() -> {
            semaphore.waitSemaphore(processName);

            try {
                System.out.println(processName + " is printing...");
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                semaphore.signalSemaphore(processName);
            }

        }).start();
    }
}
