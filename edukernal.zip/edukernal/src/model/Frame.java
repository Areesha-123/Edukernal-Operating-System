package model;

public class Frame {
    private final int frameNumber;
    private boolean occupied;
    private int processId;
    private int pageNumber;

    public Frame(int frameNumber) {
        this.frameNumber = frameNumber;
        this.occupied = false;
    }

    public int getFrameNumber() {
        return frameNumber;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public void setOccupied(boolean occupied) {
        this.occupied = occupied;
    }

    public int getProcessId() {
        return processId;
    }

    public void setProcessId(int processId) {
        this.processId = processId;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    public void reset() {
        this.occupied = false;
        this.processId = -1;
        this.pageNumber = -1;
    }
}
