package model;

public class PageTableEntry {
    private final int pageNumber;
    private final int frameNumber;

    public PageTableEntry(int pageNumber, int frameNumber) {
        this.pageNumber = pageNumber;
        this.frameNumber = frameNumber;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public int getFrameNumber() {
        return frameNumber;
    }
}
