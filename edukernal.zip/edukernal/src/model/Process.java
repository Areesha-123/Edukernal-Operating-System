package model;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class Process {
    private static final AtomicInteger idGenerator = new AtomicInteger(1);

    private final int pid;
    private String state;
    private String owner;
    private int priority;
    private int memoryRequired;
    private int arrivalTime;
    private int burstTime;
    private String processor;
    private String ioState;
    private String message;

    private List<Process> children;
    private Process parent;

    public Process(String owner, int priority, int memoryRequired, int arrivalTime, int burstTime) {
        this.pid = idGenerator.getAndIncrement();
        this.state = "Ready";
        this.owner = owner;
        this.priority = priority;
        this.memoryRequired = memoryRequired;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
        this.processor = "CPU-1";
        this.ioState = "Idle";
        this.message = "";
        this.children = new ArrayList<>();
    }

    // ====================== Getters & Setters ======================

    public int getPid() {
        return pid;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public int getMemoryRequired() {
        return memoryRequired;
    }

    public void setMemoryRequired(int memoryRequired) {
        this.memoryRequired = memoryRequired;
    }

    public int getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(int arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public int getBurstTime() {
        return burstTime;
    }

    public void setBurstTime(int burstTime) {
        this.burstTime = burstTime;
    }

    public String getProcessor() {
        return processor;
    }

    public void setProcessor(String processor) {
        this.processor = processor;
    }

    public String getIoState() {
        return ioState;
    }

    public void setIoState(String ioState) {
        this.ioState = ioState;
    }

    public List<Process> getChildren() {
        return children;
    }

    public void addChild(Process child) {
        this.children.add(child);
    }

    public Process getParent() {
        return parent;
    }

    public void setParent(Process parent) {
        this.parent = parent;
    }

    public String getMessage() {
        return message == null ? "" : message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    // ====================== Table Row Helper ======================

    public Object[] toRow() {
        return new Object[]{
                pid,
                state,
                owner,
                priority,
                memoryRequired,
                arrivalTime,
                burstTime,
                processor,
                ioState,
                message
        };
    }

    public static class PageTableEntry {
    }
}
